# National Onion Intelligence Dataset
**Curated Training Set for OnionVision AI YOLO & Vision Transformer Retraining**

- **Batch ID**: `batch_20260924_054705_c25db5`
- **Export Date**: `2026-09-24T05:47:05.390883+00:00`
- **Database Engine**: `SQLite (Fallback)`
- **Total Inspections**: 24
- **Total Bounding Box Annotations**: 486

---

## Class Definitions
| Class ID | Defect Name | Description |
| :---: | :--- | :--- |
| `0` | `healthy` | Defect-free, sound commercial grade onion |
| `1` | `damaged` | Mechanical cuts, blade punctures, bruising |
| `2` | `rotten` | Neck rot, Aspergillus niger mould, soft decay |
| `3` | `sprouted` | Apical green sprout emergence (>15mm) |
| `4` | `undersized` | Caliber under 45mm equatorial diameter |

---

## Dataset Directory Structure
```
national_onion_dataset/
  ├── data.yaml                     # Ultralytics YOLO configuration
  ├── classes.txt                   # Canonical class names
  ├── dataset_metadata.json         # Provenance & distribution manifest
  ├── annotations_coco.json         # Full dataset in COCO JSON format
  ├── Maharashtra/                  # Geographic source partition
  │   ├── images/                   # High-res raw inspection images
  │   └── labels/                   # YOLO normalized bounding box .txt files
  └── Karnataka/                    # Geographic source partition
      ├── images/
      └── labels/
```

---

## Retraining Quickstart

### 1. Ultralytics YOLOv8 / YOLOv11
```bash
pip install ultralytics

# Train custom OnionVision detector
yolo detect train \
    model=yolov8m.pt \
    data=data.yaml \
    epochs=60 \
    imgsz=640 \
    batch=16 \
    device=0
```

### 2. Hugging Face Vision Transformer (ViT / DETR / RF-Grounding)
Load `annotations_coco.json` with HuggingFace `datasets` or PyTorch `torchvision.datasets.CocoDetection`.
